# Jazz Quiz

This repository features a responsive jazz quiz built with CSS, JSON, and AngularJS.
